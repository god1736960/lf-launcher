@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
title Compilar LF Launcher para Windows

echo ============================================================
echo     LF Launcher - Compilador para Windows (.exe)
echo ============================================================
echo.
echo Este script compila LF Launcher y genera el instalador .exe.
echo Necesita (una sola vez) tener instalado:
echo   - Node.js 20+       https://nodejs.org
echo   - Rust (stable)     https://rustup.rs
echo   - Visual Studio Build Tools 2019+ (C++ Desktop)
echo   - WebView2 (ya viene en Windows 10/11)
echo.
echo Si te falta alguno, instalalo y vuelve a ejecutar este .bat.
echo ------------------------------------------------------------
echo.

REM --- Comprobar Node ---
where node >nul 2>nul
if errorlevel 1 (
    echo [ERROR] No se encuentra Node.js. Instalalo desde https://nodejs.org
    pause
    exit /b 1
)
for /f "tokens=*" %%v in ('node -v') do echo Node detectado: %%v

REM --- Comprobar Rust/cargo ---
where cargo >nul 2>nul
if errorlevel 1 (
    echo [ERROR] No se encuentra Rust (cargo). Instalalo desde https://rustup.rs
    pause
    exit /b 1
)
for /f "tokens=*" %%v in ('cargo --version') do echo Rust detectado: %%v

echo.
echo [1/2] Instalando dependencias del frontend (npm install)...
call npm install
if errorlevel 1 (
    echo [ERROR] Fallo npm install.
    pause
    exit /b 1
)

echo.
echo [2/2] Compilando la aplicacion (npm run tauri build)...
echo Esto puede tardar varios minutos la primera vez. Ten paciencia.
call npm run tauri build
if errorlevel 1 (
    echo [ERROR] Fallo la compilacion de Tauri. Revisa los mensajes de arriba.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo   LISTO. Busca tu instalador/.exe en:
echo     src-tauri\target\release\bundle\nsis\
echo     src-tauri\target\release\bundle\msi\
echo   Y el ejecutable suelto en:
echo     src-tauri\target\release\
echo ============================================================
echo.
pause
