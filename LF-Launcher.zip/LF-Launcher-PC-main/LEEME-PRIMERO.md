# LF Launcher — Cómo obtener tu .exe (léeme primero)

Hola 👋 Aquí tienes el proyecto **revisado y preparado** para generar tu
programa de Windows. Antes de nada, quiero ser **totalmente honesto** contigo
sobre una cosa importante, porque prefiero decirte la verdad a venderte humo:

## ⚠️ La verdad sobre el ".exe listo para abrir"

LF Launcher **no es** un script que se pueda "empaquetar y ya". Está hecho con
**Tauri 2 + Rust + React**, y su parte de Windows (cuentas de Microsoft para
**Bedrock**, gestión de procesos, WinRT...) usa APIs que **solo existen en
Windows**. Eso significa que el `.exe` **hay que COMPILARLO en Windows**.

Yo trabajo en un servidor Linux y **no tengo Windows**, así que **no puedo
generarte el .exe yo mismo** (sería mentirte si te dijera que sí). Lo que sí he
hecho es dejarte **dos caminos** para conseguir tu `.exe`, y con el primero
**no tienes que instalar NADA en tu PC**.

---

## ✅ Opción A (RECOMENDADA): compilar en la nube, sin instalar nada

GitHub puede compilarlo por ti en un Windows real y darte el instalador hecho.
Es **gratis** y **no instalas Node, ni Rust, ni Visual Studio** en tu ordenador.

1. Crea una cuenta en <https://github.com> (si no tienes).
2. Crea un repositorio nuevo y **sube esta carpeta** (puedes arrastrarla en la
   web con el botón *Add file → Upload files*).
3. Ve a la pestaña **Actions** del repositorio.
4. Verás el flujo **"Build Windows (.exe)"**. Pulsa **Run workflow**.
5. Espera unos minutos. Cuando termine (✔️ verde), entra en esa ejecución y
   descarga el artefacto **`LF-Launcher-Windows`**.
6. Dentro está tu instalador `.exe` / `.msi`. Instálalo y **¡a jugar!**

> Ya te he dejado listo el archivo `.github/workflows/build-windows.yml` que
> hace todo esto automáticamente. No tienes que tocar nada.

---

## ✅ Opción B: compilar en tu PC (o el de tu amigo) con un doble clic

Si prefieres hacerlo en tu ordenador, necesitas instalar **una sola vez**:

- **Node.js 20+** → <https://nodejs.org>
- **Rust (stable)** → <https://rustup.rs>
- **Visual Studio Build Tools 2019+** (carga de trabajo *Desktop C++*)
- **WebView2** (ya viene en Windows 10/11)

Después, **doble clic en `CONSTRUIR-WINDOWS.bat`**. El script instala las
dependencias y compila solo. Al terminar, tu instalador estará en:

```
src-tauri\target\release\bundle\nsis\   (instalador .exe)
src-tauri\target\release\bundle\msi\    (instalador .msi)
src-tauri\target\release\              (ejecutable suelto)
```

---

## 🎮 Sobre lo que pediste

- **Java + Bedrock:** ambos ya están soportados. El launcher usa tu **Java** ya
  instalado (lo detecta automáticamente y también puede descargar el correcto
  por versión). **Bedrock** funciona a través de tu Minecraft Bedrock de la
  Microsoft Store (por eso el `.exe` debe compilarse en Windows).
- **Skins y capas:** funcionan con cuentas **Ely.by** mediante
  *authlib-injector* (el launcher lo descarga solo). Para cuentas **offline**,
  te dejo una nota en `REVISION.md` sobre cómo ampliarlo si lo quieres.
- **"Solo abrir y jugar":** una vez instalado el `.exe` generado por la Opción A
  o B, sí es abrir y jugar. Lo único que no se puede saltar es el paso de
  **compilar** (una vez), porque así están hechas estas apps.

---

## 🙏 Nota honesta

Como no tengo Windows, **no he podido ejecutar ni probar el .exe** por mí mismo.
He **revisado el código** (mira `REVISION.md`), he mantenido **todo tu diseño
intacto** y he preparado los dos caminos de compilación. Cuando lo compiles,
cuéntame cómo va y seguimos afinando lo que haga falta. 💚
